# NESRM Ingest

This is the lambda function to handle NES Relationship Manager Ingestion.

## Develop
```bash
NODE_ENV=development
```

## Deploy

```bash
zip -r deploy.js .
```

Upload from > .zip file > Upload > Navigate to `deploy.zip` > Save


# TODO:
## SWE / DE

## Dev Ops
- [ ] sort local trial flow
- [ ] configure aws cli
- [ ] configure lambda build Upload
- [ ] configure github CD process
- [ ] develop tests
- [ ] configure test CI process
